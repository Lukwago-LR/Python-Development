import requests
from flask import Flask, request
from flask import render_template

app = Flask(__name__)
url = "https://api.npoint.io/8c4a10badec4f5363f36"
response = requests.get(url=url)
data = response.json()


@app.route("/")
def home():
    return render_template("index.html", data=data)


@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        dat = request.form
        user_name = dat["username"]
        user_email = dat["email"]
        user_phone = dat["phone"]
        message = dat["message"]
        return render_template("contact.html", response=True)
    elif request.method == "GET":
        return render_template("contact.html", response=False)


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/post/<int:index>")
def post(index):
    for d in data:
        if d["id"] == index:
            dict_data = d
    return render_template("post.html", dict=dict_data)


if __name__ == "__main__":
    app.run(debug=True)
