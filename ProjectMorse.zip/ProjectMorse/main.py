# from shlex import join
#
# morse_code_dict = {
#     'A': '.-',
#     'B': '-...',
#     'C': '-.-.',
#     'D': '-..',
#     'E': '.',
#     'F': '..-.',
#     'G': '--.',
#     'H': '....',
#     'I': '..',
#     'J': '.---',
#     'K': '-.-',
#     'L': '.-..',
#     'M': '--',
#     'N': '-.',
#     'O': '---',
#     'P': '.--.',
#     'Q': '--.-',
#     'R': '.-.',
#     'S': '...',
#     'T': '-',
#     'U': '..-',
#     'V': '...-',
#     'W': '.--',
#     'X': '-..-',
#     'Y': '-.--',
#     'Z': '--..',
#     '0': '-----',
#     '1': '.----',
#     '2': '..---',
#     '3': '...--',
#     '4': '....-',
#     '5': '.....',
#     '6': '-....',
#     '7': '--...',
#     '8': '---..',
#     '9': '----.',
#     ' ': '/',
#     '.': '.-.-.-',
#     ',': '--..--',
#     '?': '..--..',
#     "'": '.----.',
#     '!': '-.-.--',
#     '/': '-..-.',
#     '(': '-.--.',
#     ')': '-.--.-',
#     '&': '.-...',
#     ':': '---...',
#     ';': '-.-.-.',
#     '=': '-...-',
#     '+': '.-.-.',
#     '-': '-....-',
#     '_': '..--.-',
#     '"': '.-..-.',
#     '$': '...-..-',
#     '@': '.--.-.',
#     '¿': '..-.-',
#     '¡': '--...-',
# }
#
# wordInput = list(str(input("Please enter a string: ")).upper())
# morseString = []
# for char in wordInput:
#
#     for key in morse_code_dict.keys():
#         if key == char:
#             morseString.append(morse_code_dict.get(key))
#
# print(join(morseString))

import base64

with open("malignant_cancer.jpeg", "rb") as image:
    converted_string = base64.b64encode(image.read())

with open("binary_file.bin", "wb") as file:
    file.write(converted_string)

# file = open("binary_file.bin", "rb")
# bytes_file = file.read()
# file.close()
#
# decoded_image = open("decoded.jpg", "wb")
# decoded_image.write(base64.b64decode(bytes_file))
# decoded_image.close()
